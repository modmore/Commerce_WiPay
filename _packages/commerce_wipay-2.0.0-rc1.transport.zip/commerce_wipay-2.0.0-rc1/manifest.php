<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Wipay for Commerce
------------------------

WiPay payments integration to allow Commerce to accept payments through WiPay.

To use the sandbox for testing:

- On the payment method, check the "Use Sandbox" checkbox.
- Account Number should be set to 1234567890
- Api Key should be set to 123
- Select the closest API endpoint for your server. Default is Trinidad and Tobago.

Example test card accepted: 4111111111111111 / rejected: 4666666666662222 / more via https://wipaycaribbean.com/credit-card-documentation/

Important: For the return from WiPay to work, you **must** be using friendly URLs in MODX. Otherwise, the redirect from WiPay back to the Checkout may fail.
It appears that the API also checks that the response_url is valid so it won\'t return on a local environment. Make sure the return_url is accessible from the internet.
',
    'changelog' => 'Wipay for Commerce 2.0.0-rc1
---------------------------
Released on 2021-07-23

Update to new WiPay API specs. Older versions are broken.

Wipay for Commerce 1.0.0-pl
---------------------------
Released on 2020-06-29

- Fix total amount to be decimal formatted instead of integer

Wipay for Commerce 1.0.0-rc1
---------------------------
Released on 2020-06-29

- Initial release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2d81d7c3e2f00bfe09d870546a0654ca',
      'native_key' => 'commerce_wipay',
      'filename' => 'modNamespace/6607e51af492dfbb5c89cad4dc58742d.vehicle',
      'namespace' => 'commerce_wipay',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '435670c87b63603a491828b27a585480',
      'native_key' => '435670c87b63603a491828b27a585480',
      'filename' => 'xPDOFileVehicle/1d51f6a6112670bcbcfae7babe154749.vehicle',
    ),
  ),
);