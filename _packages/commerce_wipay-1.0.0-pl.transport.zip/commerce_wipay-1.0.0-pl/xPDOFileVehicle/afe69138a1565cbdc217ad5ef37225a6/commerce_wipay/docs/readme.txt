Wipay for Commerce
------------------------

WiPay payments integration to allow Commerce to accept payments through WiPay.

Example test card accepted: 4111111111111111 / rejected: 4666666666662222 / more via https://wipaycaribbean.com/credit-card-documentation/

Important: For the return from WiPay to work, you **must** be using friendly URLs in MODX. Otherwise, the redirect from WiPay back to the Checkout may fail.
