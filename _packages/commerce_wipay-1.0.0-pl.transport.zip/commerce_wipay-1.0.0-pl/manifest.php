<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Wipay for Commerce
------------------------

WiPay payments integration to allow Commerce to accept payments through WiPay.

Example test card accepted: 4111111111111111 / rejected: 4666666666662222 / more via https://wipaycaribbean.com/credit-card-documentation/

Important: For the return from WiPay to work, you **must** be using friendly URLs in MODX. Otherwise, the redirect from WiPay back to the Checkout may fail.
',
    'changelog' => 'Wipay for Commerce 1.0.0-pl
---------------------------
Released on 2020-06-29

- Fix total amount to be decimal formatted instead of integer

Wipay for Commerce 1.0.0-rc1
---------------------------
Released on 2020-06-29

- Initial release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'de5c91f9c28d0b8e27fcb7a2b868b070',
      'native_key' => 'commerce_wipay',
      'filename' => 'modNamespace/4eb03ee7ba80900a8090f48f8bc7764d.vehicle',
      'namespace' => 'commerce_wipay',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'e0108fcb802687558ac923a5763cb2be',
      'native_key' => 'e0108fcb802687558ac923a5763cb2be',
      'filename' => 'xPDOFileVehicle/afe69138a1565cbdc217ad5ef37225a6.vehicle',
    ),
  ),
);