<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Wipay for Commerce
------------------------

WiPay payments integration to allow Commerce to accept payments through WiPay.

Example test card accepted: 4111111111111111 / rejected: 4666666666662222 / more via https://wipaycaribbean.com/credit-card-documentation/

Important: For the return from WiPay to work, you **must** be using friendly URLs in MODX. Otherwise, the redirect from WiPay back to the Checkout may fail.
',
    'changelog' => 'Wipay for Commerce 1.0.0-pl
---------------------------------
Released on

- Initial release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'da009274d18c9b418b69b62053f0189f',
      'native_key' => 'commerce_wipay',
      'filename' => 'modNamespace/bba5f5a5c0afb9a6eea6b146199b497f.vehicle',
      'namespace' => 'commerce_wipay',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '0eb9a1ee4251c2181ecf99b2b569e794',
      'native_key' => '0eb9a1ee4251c2181ecf99b2b569e794',
      'filename' => 'xPDOFileVehicle/b5a460a0aa347eb076349db701b328e9.vehicle',
    ),
  ),
);